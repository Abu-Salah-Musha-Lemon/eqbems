

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('main'); ?>

<div class="container-fluid">

    <h1 class="h3 mb-4">
        Dashboard
    </h1>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layouts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\srleo\Documents\eqbems\resources\views/dashboard/index.blade.php ENDPATH**/ ?>